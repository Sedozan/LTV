"""
End-to-end POC. This is the script you run in front of the client.

    python run_poc.py                 # stub extractor, sample NCCI, synthetic claims
    PKB_LLM=DBFM python run_poc.py    # real extraction via Databricks serving
    PKB_MODE=DATABRICKS python run_poc.py

Seven steps, each printing something a client can read.
"""
from __future__ import annotations

import os
import sys
import textwrap

import pandas as pd

import config
import store
import ingest_ncci
import extract_ahcccs
import validate_gate
import detector_gen
import run_detectors
import analysis
import synth_claims
from gold_set import GOLD, unverified_count

pd.set_option("display.width", 200)
pd.set_option("display.max_colwidth", 60)

HERE = os.path.dirname(os.path.abspath(__file__))
BAR = "=" * 78


def head(n, title):
    print(f"\n{BAR}\n  STEP {n}  |  {title}\n{BAR}")


# Fallback policy text so the POC runs before you drop in real PDFs.
DEMO_POLICY_TEXT = """
Outpatient Behavioral Health Billing -- Service Limits

H2015 Comprehensive community support services are limited to 16 units per day.
H2017 Psychosocial rehabilitation services are limited to 8 units per day.
H0038 Self-help/peer services require the appropriate modifier when billed.
H2025 Ongoing support to maintain employment: see daily unit limits.

Providers must document medical necessity in the member record for each
encounter. Prior authorization is required for selected services.
"""


def main() -> int:
    run_id = store.new_run_id()
    print(f"\nPOC: {config.POC_NAME}")
    print(f"mode={config.MODE}  llm={config.LLM_BACKEND}  run_id={run_id}")

    store.ensure_schema()
    if os.environ.get("PKB_RESET", "1") == "1":
        store.reset()

    # ---------------------------------------------------------------- 1
    head(1, "NCCI ingest -- the coding-edit floor (no LLM)")
    mue, ptp = config.NCCI_MUE_PATH, config.NCCI_PTP_PATH
    if not (os.path.exists(mue) and os.path.exists(ptp)):
        print("  real NCCI files not found -> writing illustrative stand-ins")
        print("  (download the real quarterly files before the client demo)")
        mue, ptp = ingest_ncci.sample_files(os.path.join(HERE, "data"))
    ncci_rules = ingest_ncci.ingest(mue, ptp)
    print(f"  ingested {len(ncci_rules)} NCCI rules "
          f"(plane=coding_edit, binding=mandatory)")
    for r in ncci_rules[:4]:
        print(f"    {r.rule_id}  {r.statement}")

    # ---------------------------------------------------------------- 2
    head(2, "AHCCCS overlay extraction -- prose to predicates (LLM)")
    ahcccs_rules, errors = extract_ahcccs.extract_dir(
        os.path.join(HERE, config.AHCCCS_PDF_DIR))
    if not ahcccs_rules:
        print("  no PDFs found -> extracting from inline demo policy text")
        ahcccs_rules = extract_ahcccs.extract_from_text(
            DEMO_POLICY_TEXT,
            source_doc="AHCCCS Outpatient BH Billing Codes (July 2023)",
            locator="service limits section")
    print(f"  extracted {len(ahcccs_rules)} candidate rules, "
          f"{len(errors)} section errors persisted")
    for r in ahcccs_rules[:6]:
        flag = " [AMBIGUOUS]" if r.ambiguity_flag else ""
        print(f"    {r.rule_id}  {r.statement[:66]}{flag}")

    # ---------------------------------------------------------------- 3
    head(3, "Validation gate -- nothing enters the KB unvetted")
    accepted, rejected = validate_gate.gate(ncci_rules + ahcccs_rules + GOLD)
    print(f"  accepted  {len(accepted)}")
    print(f"  rejected  {len(rejected)}   <- show these; the gate earns trust")
    for row in rejected[:4]:
        print(f"    QUARANTINED {row['rule_id']}: {row['validation_errors'][:90]}")
    patched = [a for a in accepted if a["validation_status"] == "patched"]
    for row in patched[:4]:
        print(f"    PATCHED     {row['rule_id']}: {row.get('patch_notes','')[:80]}")

    store.write("rules", accepted, run_id)
    store.write("rules_rejected", rejected, run_id)

    conflicts = validate_gate.conflict_report(accepted)
    if conflicts:
        print(f"\n  cross-source threshold conflicts: {len(conflicts)}")
        for c in conflicts:
            print(f"    {c['code']}: {c['thresholds']} -> {c['resolution']}")

    # ---------------------------------------------------------------- 4
    head(4, "The KB -- what the asset actually contains")
    print(analysis.kb_summary(accepted).to_string(index=False))
    amb = [a for a in accepted if a["ambiguity_flag"]]
    print(f"\n  ambiguous rules preserved (NOT auto-resolved): {len(amb)}")
    for a in amb:
        alts = a["alternates"]
        print(f"    {a['rule_id']} {a['codes']}: "
              f"{[x.get('threshold') for x in alts]} @ "
              f"{[x.get('locator') for x in alts]}")

    # ---------------------------------------------------------------- 5
    head(5, "Detector compilation -- deterministic, no LLM in the loop")
    detectors = detector_gen.build_detectors(accepted)
    compiled = [d for d in detectors if d["compiled"]]
    leads = [d for d in detectors if not d["compiled"]]
    print(f"  compiled to SQL      {len(compiled)}")
    print(f"  routed to human      {len(leads)}")
    for d in leads[:5]:
        print(f"    LEAD {d['rule_id']}: {d['skip_reason'][:88]}")
    if compiled:
        ex = compiled[0]
        print(f"\n  example SQL for {ex['rule_id']}:")
        print(textwrap.indent(ex["sql"], "    "))
    store.write("detectors", detectors, run_id)

    # ---------------------------------------------------------------- 6
    head(6, "Execute against claims -- with a known answer key")
    claims = synth_claims.build()
    if config.MODE == "LOCAL":
        print(f"  synthetic claims: {len(claims)} rows (no PHI)")
    findings, exec_errors = run_detectors.run_all(detectors, claims)
    print(f"  findings: {len(findings)}   exec errors: {len(exec_errors)}")
    for e in exec_errors[:3]:
        print(f"    ERROR {e['rule_id']}: {e['error'][:100]}")
    if not findings.empty:
        cols = [c for c in ("rule_id", "member_id", "code", "observed_units",
                            "allowed_units", "dos", "severity")
                if c in findings.columns]
        print(textwrap.indent(findings[cols].to_string(index=False), "    "))
        store.write("findings", findings, run_id)

    flagged = set(findings["claim_id"]) if "claim_id" in findings.columns else set()
    origin_by_rule = {a["rule_id"]: a["origin"] for a in accepted}
    print("\n  answer-key check:")
    bad = False

    # Positive assertions FIRST. Checking only for false positives lets a
    # silently under-flagging detector look perfect.
    for label, expect in synth_claims.EXPECTED.items():
        if expect & flagged:
            print(f"    PASS  detected: {label}")
        else:
            print(f"    FAIL  MISSED: {label} (expected any of {sorted(expect)})")
            bad = True

    for cid, why in synth_claims.MUST_NOT_FLAG.items():
        if cid in flagged:
            print(f"    FAIL  {cid} flagged but must not be -- {why}")
            bad = True

    # per-rule effective dates, not one global date
    for cid, spec in synth_claims.FEDERAL_ONLY_WINDOW.items():
        if findings.empty or "claim_id" not in findings.columns:
            continue
        hits = findings[findings["claim_id"] == cid]
        origins = {origin_by_rule.get(r, "?") for r in hits["rule_id"]}
        if spec["must_flag_origin"] not in origins:
            print(f"    FAIL  {cid} should be flagged by "
                  f"{spec['must_flag_origin']} -- {spec['why']}")
            bad = True
        elif spec["must_not_flag_origin"] in origins:
            print(f"    FAIL  {cid} wrongly flagged by "
                  f"{spec['must_not_flag_origin']} -- {spec['why']}")
            bad = True
        else:
            print(f"    PASS  {cid} flagged by federal rule only "
                  f"-- {spec['why']}")

    if not bad:
        print("    PASS  no excluded claim was flagged")
        print("          (pre-effective-date and ambiguous rules correctly skipped)")

    lead_df = run_detectors.review_leads(detectors)
    print(f"\n  documentation-review leads (never auto-flagged): {len(lead_df)}")

    # ---------------------------------------------------------------- 7
    head(7, "Gap analysis + extraction benchmark")
    gap = analysis.gap_analysis(accepted)
    silent = gap[gap["coverage"] == "federal_only"]
    print(f"  codes with a federal floor but NO state rule: {len(silent)}")
    if not silent.empty:
        print(textwrap.indent(
            silent[["code", "risk", "ncci_rules"]].to_string(index=False), "    "))
    store.write("gap", gap, run_id)

    bench = analysis.benchmark([a for a in accepted if a["origin"] == "llm"])
    print(f"\n  extraction benchmark: {bench.get('status')}")
    for k, v in bench.items():
        if k not in ("status", "missed"):
            print(f"    {k}: {v}")
    if unverified_count():
        print(f"\n  NOTE: {unverified_count()} gold rules are still scaffold. "
              f"Transcribe and flip verified=True before quoting accuracy.")

    print(f"\n{BAR}\n  DONE. Tables written under "
          f"{config.LOCAL_ROOT if config.MODE == 'LOCAL' else store.fq('rules')}"
          f"\n{BAR}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
