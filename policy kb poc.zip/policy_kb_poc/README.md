# Policy Knowledge Base — POC

Proves the thesis on a deliberately small corpus: **the KB is a shared,
structured asset; interpretation happens once, upstream; downstream is
mechanical translation.** If the client likes it, the same machinery scales to
the rest of the corpus without redesign.

---

## Why this scope

**One clinical area: outpatient behavioral health, AHCCCS FFS.**

Chosen because it is the only slice that exercises all three planes and gives
you a defensible answer to "how do you know it's right":

| Reason | Why it matters for a POC |
|---|---|
| You already have a hand-verified gold set here | Accuracy claims are measurable, not asserted |
| BH is where AHCCCS is most state-specific and NCCI is thinnest | Demonstrates why the plane model exists |
| H2025 has a **real** contradiction in the source deck | Best demo artifact you own — the KB preserves it instead of guessing |
| Small code set (~23 codes) | Whole run is inspectable by a human in one sitting |

Do **not** widen the corpus for the POC. A bigger KB does not make a better
demo; a KB whose every row a client can check does.

---

## Install

```bash
pip install pandas pyarrow duckdb pdfplumber openpyxl
# optional, only for real extraction:
pip install openai            # Databricks serving (OpenAI-compatible)
pip install transformers torch  # local HF
```

## Run

```bash
python run_poc.py            # full pipeline, stub extractor, ~2 seconds
python tests/test_pipeline.py   # 19 regression tests
```

Everything is offline and PHI-free by default: stand-in NCCI files, inline
policy text, synthetic claims with a known answer key.

### Switching on the real pieces

```bash
# 1. Real NCCI (download the PUBLIC quarterly files first)
#    https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files
python ingest_ncci.py --inspect data/your_mue_file.xlsx   # ALWAYS check columns first
export PKB_NCCI_MUE=data/your_mue_file.xlsx
export PKB_NCCI_PTP=data/your_ptp_file.xlsx

# 2. Real AHCCCS PDFs
mkdir -p data/ahcccs && cp ~/Downloads/*.pdf data/ahcccs/

# 3. Real extraction
export PKB_LLM=DBFM
export PKB_DBFM_ENDPOINT=<your endpoint>   # verify the name in your workspace
export DATABRICKS_HOST=... DATABRICKS_TOKEN=...

# 4. On-platform
export PKB_MODE=DATABRICKS PKB_CATALOG=main PKB_SCHEMA=policy_kb
```

---

## Files

| File | Role |
|---|---|
| `schema.py` | **The rule object + closed predicate grammar. This is the product.** |
| `config.py` | Scope, paths, table names, model backend |
| `store.py` | Delta/Unity Catalog on Databricks, parquet locally. Supersede, never delete |
| `ingest_ncci.py` | NCCI MUE/PTP → rule objects. **No LLM** — it's a file read |
| `extract_ahcccs.py` | PDF → sections → LLM → rule objects. The only place an LLM touches rule logic |
| `llm_client.py` | STUB / Databricks serving / local HF |
| `stub_extractions.py` | Deterministic fake extractions (includes planted defects) |
| `validate_gate.py` | The quality bar. Patch, quarantine, collapse duplicates, report conflicts |
| `detector_gen.py` | **Predicate → SQL, deterministically.** LLM path is a cross-check only |
| `run_detectors.py` | Executes detectors (duckdb / Spark), attaches citations |
| `synth_claims.py` | Synthetic claims + **answer key** |
| `analysis.py` | Gap analysis (NCCI floor vs state overlay) + extraction benchmark |
| `gold_set.py` | Hand-verified benchmark rules — **mostly scaffold, see below** |
| `run_poc.py` | The seven-step demo |

---

## What to actually show the client

1. **Step 3 — the rejections.** Do not hide them. A gate that quarantines a
   malformed code and downgrades an over-claimed rule is why the output can be
   trusted. Showing only successes is what makes reviewers suspicious.
2. **Step 4 — H2025.** Both thresholds, both slide citations, `ambiguity_flag`.
   The KB found a contradiction in their own training deck and refused to guess.
   This usually lands harder than any detection result.
3. **Step 5 — the compiled SQL.** Point out there is no LLM in this path. The
   grammar is closed, so the SQL is provably the same every run.
4. **Step 6 — the answer key.** Especially `C055`: flagged by the federal rule,
   not the state rule, because their effective dates differ. Per-rule date
   awareness, not a global filter.
5. **Step 7 — the gap.** Codes with a federal floor and no state rule. That is
   the OIG-differentiated output.

---

## Honest caveats — say these out loud

- **The gold set is scaffold.** Four of five rules ship with `verified=False`
  and placeholder content. `benchmark.py` refuses to score against them.
  Transcribe from your source slides and flip the flag before quoting any
  accuracy number. Precision in a stub run is meaningless.
- **The stand-in NCCI values are illustrative, not real.** Replace with the
  actual quarterly download before the client sees a number.
- **NCCI column names shift between quarters.** Always run `--inspect` against
  the real file; the fuzzy matcher is a convenience, not a guarantee.
- **Gate #2 is unresolved: are there CMS-approved AZ deactivations?** A
  deactivated edit does not bind in Arizona. Ingesting it produces false
  positives against your own state's approved policy. The `deactivated` field
  exists; nothing populates it yet.
- **Contractor data access.** The operative state files are on RISSNET
  (state staff only). Contractors use the public cms.gov files. Confirm your
  entitlement.
- **PTP self-join assumes one line per claim row.** Verify against the real
  claims grain before trusting pair detection at volume.
- **Claims schema is unverified** against the real extract. Fix
  `config.CLAIM_COLS` first; every compiled detector depends on it.

---

## Two bugs found while building this — keep the tests

1. **Ambiguous rules were being quarantined.** A null threshold is *legitimate*
   when the source contradicts itself. Quarantining lost the exact contradiction
   the KB exists to surface. Ambiguous rules now enter as `needs_review`.
2. **NULL modifiers made detectors silently under-flag.** `mod_1 IN ('HQ')` is
   NULL when `mod_1` is NULL, so `NOT(...)` is NULL and a claim *missing* the
   required modifier — the violation itself — never matched. Fixed with
   COALESCE. This is the failure mode that makes generated SQL dangerous: it
   fails silently and looks clean.

Both are covered by tests. Do not delete them.

---

## Scaling after approval

Nothing here changes shape when the corpus grows:

- More NCCI codes → drop the `POC_CODE_SET` filter
- More AHCCCS docs → point `PKB_AHCCCS_PDFS` at a bigger directory
- New rule kinds → add one compiler to `detector_gen.COMPILERS` and one entry
  to `schema.PREDICATE_TYPES`. **The closed grammar is the thing to protect** —
  if predicates start arriving as free text, the deterministic compile is gone
  and you are back to trusting an LLM with thresholds.
