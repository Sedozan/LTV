"""
Execute compiled detectors against claims.

LOCAL      -> duckdb over the synthetic parquet
DATABRICKS -> spark.sql over the real claims table

Every finding carries its rule_id, citation and effective date, so an
investigator can trace any flagged row back to the exact policy text.
"""
from __future__ import annotations

import pandas as pd

import config


def _run_local(sql: str, claims: pd.DataFrame) -> pd.DataFrame:
    import duckdb
    con = duckdb.connect()
    con.register(config.CLAIMS_TABLE, claims)
    try:
        return con.execute(sql).fetchdf()
    finally:
        con.close()


def _run_spark(sql: str) -> pd.DataFrame:
    from store import spark
    return spark().sql(sql).toPandas()


def run_one(detector: dict, claims: pd.DataFrame | None = None) -> pd.DataFrame:
    if not detector.get("compiled"):
        return pd.DataFrame()
    sql = detector["sql"]
    df = _run_local(sql, claims) if config.MODE == "LOCAL" else _run_spark(sql)
    if df.empty:
        return df
    df["rule_id"] = detector["rule_id"]
    df["plane"] = detector["plane"]
    df["binding_status"] = detector["binding_status"]
    df["policy_statement"] = detector["statement"]
    df["citation"] = f"{detector['source_doc']} :: {detector['source_locator']}"
    df["effective_date"] = detector.get("effective_date")
    df["severity"] = ("violation" if detector["binding_status"] == "mandatory"
                      else "potential_violation")
    return df


def run_all(detectors: list[dict], claims: pd.DataFrame | None = None
            ) -> tuple[pd.DataFrame, list[dict]]:
    """Returns (findings, review_leads)."""
    findings, errors = [], []
    for d in detectors:
        if not d.get("compiled"):
            continue
        try:
            r = run_one(d, claims)
            if not r.empty:
                findings.append(r)
        except Exception as e:  # noqa: BLE001
            errors.append({"rule_id": d["rule_id"], "error": str(e)[:400],
                           "sql": d["sql"][:1000]})
    out = (pd.concat(findings, ignore_index=True) if findings else pd.DataFrame())
    return out, errors


def review_leads(detectors: list[dict]) -> pd.DataFrame:
    """Rules that could not be mechanized -- routed to a human, not dropped."""
    rows = [{
        "rule_id": d["rule_id"], "plane": d["plane"],
        "statement": d["statement"],
        "citation": f"{d['source_doc']} :: {d['source_locator']}",
        "disposition": d["disposition"], "reason": d["skip_reason"],
    } for d in detectors if not d.get("compiled")]
    return pd.DataFrame(rows)
