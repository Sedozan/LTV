"""
The rule object. This IS the product.

Everything downstream -- detector SQL, ML features, narratives, lookup --
reads this and nothing else. If a consumer has to re-read the source PDF,
the KB has failed.

Design rule: interpretation happens HERE, once, and is human-reviewable.
Downstream is mechanical translation only.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field, asdict
from datetime import date
from typing import Any, Optional

# ---------------------------------------------------------------- vocab

PLANES = {"coding_edit", "coverage_scope", "enforcement"}

BINDING = {
    "mandatory",      # federal statute/reg (incl. NCCI under ACA 6507)
    "state_plan",     # CMS-approved State Plan / waiver
    "state_policy",   # AHCCCS rule / AMPM / ACOM / FFS manual
    "contract",       # MCO / ACC contract term
    "guidance",       # bulletin, FAQ, training deck
    "advisory",       # clinical guideline, literature
}

# Binding rank: lower number = higher authority. Used only WITHIN a plane.
BINDING_RANK = {
    "mandatory": 0, "state_plan": 1, "state_policy": 2,
    "contract": 3, "guidance": 4, "advisory": 5,
}

# The predicate grammar. Small and closed on purpose: a closed grammar is what
# lets detector SQL be compiled deterministically instead of guessed by an LLM.
PREDICATE_TYPES = {
    "max_units_per_line":   ("code", "threshold"),
    "max_units_per_day":    ("code", "threshold"),
    "code_pair_prohibited": ("code_a", "code_b"),
    "pos_allowed":          ("code", "allowed_pos"),
    "modifier_required":    ("code", "required_modifiers"),
    "frequency_limit":      ("code", "max_count", "window_days"),
    "provider_type_allowed": ("code", "allowed_provider_types"),
    "not_checkable":        ("reason",),
}

NOT_CHECKABLE_REASONS = {
    "no_claim_field",        # nothing in the claim can test it
    "requires_medical_record",
    "requires_member_attribute",  # DOB / dx not in the extract yet
    "process_obligation",    # enforcement plane: a human/plan step, not a claim fact
    "ambiguous_source",
}


class RuleValidationError(ValueError):
    pass


# ---------------------------------------------------------------- rule object

@dataclass
class Rule:
    # --- identity
    rule_id: str = ""                      # deterministic content hash
    origin: str = "llm"                    # ncci | llm | manual
    plane: str = "coverage_scope"
    binding_status: str = "state_policy"

    # --- what the rule says
    statement: str = ""                    # normalized human-readable statement
    predicate: dict[str, Any] = field(default_factory=dict)
    codes: list[str] = field(default_factory=list)
    population: str = "all"                # e.g. all | bh_outpatient | ltc

    # --- mechanizability (the guardrail)
    machine_checkable: bool = False
    not_checkable_reason: Optional[str] = None
    required_claim_fields: list[str] = field(default_factory=list)

    # --- ambiguity (never silently resolved)
    ambiguity_flag: bool = False
    ambiguity_note: Optional[str] = None
    alternates: list[dict[str, Any]] = field(default_factory=list)

    # --- provenance
    source_doc: str = ""
    source_locator: str = ""               # section / slide / page
    source_url: str = ""
    doc_version: str = ""
    doc_hash: str = ""

    # --- time
    effective_date: Optional[str] = None   # ISO; only if the source states it
    end_date: Optional[str] = None

    # --- authority notes
    deactivated: bool = False              # CMS-approved NCCI deactivation in AZ
    supersedes: Optional[str] = None
    notes: str = ""

    # ------------------------------------------------------------ helpers

    def content_key(self) -> str:
        """Stable identity: what the rule says, not how it was worded."""
        p = json.dumps(self.predicate, sort_keys=True, default=str)
        return "|".join([self.plane, p, ",".join(sorted(self.codes)),
                         self.population, self.source_doc])

    def assign_id(self) -> "Rule":
        h = hashlib.sha256(self.content_key().encode()).hexdigest()[:16]
        prefix = {"ncci": "NCCI", "manual": "MAN", "llm": "EXT"}.get(self.origin, "EXT")
        self.rule_id = f"{prefix}-{h}"
        return self

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def authority_rank(self) -> int:
        return BINDING_RANK.get(self.binding_status, 9)


# ---------------------------------------------------------------- validation

_CODE_RE = re.compile(r"^[A-Z0-9]{5}$")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def validate(rule: Rule) -> list[str]:
    """Return a list of problems. Empty list = clean."""
    errs: list[str] = []

    if rule.plane not in PLANES:
        errs.append(f"bad plane: {rule.plane}")
    if rule.binding_status not in BINDING:
        errs.append(f"bad binding_status: {rule.binding_status}")
    if rule.origin not in {"ncci", "llm", "manual"}:
        errs.append(f"bad origin: {rule.origin}")
    if not rule.statement.strip():
        errs.append("empty statement")

    ptype = rule.predicate.get("type")
    if ptype not in PREDICATE_TYPES:
        errs.append(f"unknown predicate type: {ptype!r}")
    else:
        # A field may be legitimately null when the SOURCE is contradictory and
        # every competing reading is recorded in `alternates`. That is a rule we
        # want IN the KB (as needs_review) -- not one we throw away. Quarantining
        # it would lose the very contradiction the KB exists to surface.
        alt_keys = {k for a in rule.alternates for k in a} if rule.alternates else set()
        for req in PREDICATE_TYPES[ptype]:
            if rule.predicate.get(req) in (None, "", [], {}):
                if rule.ambiguity_flag and req in alt_keys:
                    continue
                errs.append(f"predicate.{req} missing for {ptype}")

    for c in rule.codes:
        if not _CODE_RE.match(c):
            errs.append(f"malformed code: {c}")

    # mechanizability must be internally consistent
    if rule.machine_checkable:
        if ptype == "not_checkable":
            errs.append("machine_checkable=True with not_checkable predicate")
        if not rule.required_claim_fields:
            errs.append("machine_checkable=True but no required_claim_fields")
    else:
        if not rule.not_checkable_reason:
            errs.append("machine_checkable=False requires not_checkable_reason")
        elif rule.not_checkable_reason not in NOT_CHECKABLE_REASONS:
            errs.append(f"bad not_checkable_reason: {rule.not_checkable_reason}")

    # ambiguity must carry its alternates
    if rule.ambiguity_flag and len(rule.alternates) < 1:
        errs.append("ambiguity_flag=True but no alternates recorded")
    if rule.ambiguity_flag and rule.machine_checkable:
        errs.append("ambiguous rule must not be machine_checkable "
                    "(a detector would silently pick one reading)")

    # provenance is non-negotiable -- an uncited rule is a rumor
    if not rule.source_doc:
        errs.append("missing source_doc")
    if not rule.source_locator:
        errs.append("missing source_locator")

    for d in (rule.effective_date, rule.end_date):
        if d is not None and not _DATE_RE.match(str(d)):
            errs.append(f"bad date format: {d}")

    return errs


def is_clean(rule: Rule) -> bool:
    return not validate(rule)
