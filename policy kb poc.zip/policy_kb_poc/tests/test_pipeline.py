"""
Regression tests. Run: python tests/test_pipeline.py   (no pytest needed)

Several of these encode bugs found while building. Keep them.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd  # noqa: E402

import detector_gen  # noqa: E402
import run_detectors  # noqa: E402
import synth_claims  # noqa: E402
import validate_gate  # noqa: E402
from schema import Rule, validate  # noqa: E402

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(("  PASS  " if cond else "  FAIL  ") + name + (f"  -- {detail}" if detail and not cond else ""))


def _rule(**kw):
    base = dict(statement="s", source_doc="d", source_locator="l",
                machine_checkable=False, not_checkable_reason="no_claim_field",
                predicate={"type": "max_units_per_day", "code": "H2015",
                           "threshold": 8})
    base.update(kw)
    return Rule(**base).assign_id()


# ---------------------------------------------------------------- schema

def test_schema():
    print("\nschema")
    r = _rule(machine_checkable=True, not_checkable_reason=None,
              required_claim_fields=["proc_cd", "units"])
    check("clean rule validates", validate(r) == [], str(validate(r)))

    r = _rule(machine_checkable=True, required_claim_fields=[])
    check("checkable rule without claim fields is rejected", validate(r) != [])

    r = _rule(codes=["H999"])
    check("malformed code is rejected", any("malformed" in e for e in validate(r)))

    r = _rule(source_locator="")
    check("uncited rule is rejected", any("locator" in e for e in validate(r)))

    # BUG FOUND IN BUILD: ambiguous rules were quarantined instead of admitted.
    r = _rule(predicate={"type": "max_units_per_day", "code": "H2025",
                         "threshold": None},
              ambiguity_flag=True, not_checkable_reason="ambiguous_source",
              alternates=[{"threshold": 8, "locator": "s11"},
                          {"threshold": 4, "locator": "s14"}])
    check("ambiguous rule with alternates is ADMITTED", validate(r) == [],
          str(validate(r)))

    r = _rule(ambiguity_flag=True, alternates=[])
    check("ambiguity without alternates is rejected", validate(r) != [])

    r = _rule(ambiguity_flag=True, machine_checkable=True,
              required_claim_fields=["proc_cd"], not_checkable_reason=None,
              alternates=[{"threshold": 8}])
    check("ambiguous + machine_checkable is rejected", validate(r) != [])


# ---------------------------------------------------------------- gate

def test_gate():
    print("\nvalidation gate")
    r = _rule(plane="enforcement", machine_checkable=True,
              required_claim_fields=["proc_cd"], not_checkable_reason=None)
    acc, rej = validate_gate.gate([r])
    check("enforcement plane forced non-checkable",
          acc and acc[0]["machine_checkable"] is False)

    r = _rule(predicate={"type": "not_checkable", "reason": "requires_medical_record"},
              machine_checkable=True, required_claim_fields=["x"],
              not_checkable_reason=None)
    acc, rej = validate_gate.gate([r])
    check("not_checkable predicate forced non-checkable",
          acc and acc[0]["machine_checkable"] is False)

    fed = _rule(origin="ncci", binding_status="mandatory", plane="coding_edit",
                machine_checkable=True, not_checkable_reason=None,
                required_claim_fields=["proc_cd", "units"])
    state = _rule(origin="llm", binding_status="guidance", plane="coding_edit",
                  machine_checkable=True, not_checkable_reason=None,
                  required_claim_fields=["proc_cd", "units"])
    acc, _ = validate_gate.gate([state, fed])
    check("duplicate collapses to the higher authority",
          len(acc) == 1 and acc[0]["binding_status"] == "mandatory")

    a = _rule(predicate={"type": "max_units_per_day", "code": "H1", "threshold": 8})
    b = _rule(predicate={"type": "max_units_per_day", "code": "H1", "threshold": 4})
    a.codes = b.codes = ["H2015"]
    conflicts = validate_gate.conflict_report(
        [dict(a.to_dict(), origin="ncci"), dict(b.to_dict(), origin="llm")])
    check("threshold conflict reported, not silently resolved", len(conflicts) == 1)


# ---------------------------------------------------------------- compiler

def test_compiler():
    print("\ndetector compiler")
    r = _rule(machine_checkable=False, not_checkable_reason="requires_medical_record")
    try:
        detector_gen.compile_rule(r.to_dict())
        check("non-checkable rule refuses to compile", False)
    except detector_gen.NotCompilable:
        check("non-checkable rule refuses to compile", True)

    r = _rule(machine_checkable=True, not_checkable_reason=None,
              required_claim_fields=["proc_cd", "units"], effective_date="2023-07-01")
    sql = detector_gen.compile_rule(r.to_dict())
    check("compiled SQL carries the effective-date guard", "2023-07-01" in sql)

    sql2 = detector_gen.compile_rule(r.to_dict())
    check("compilation is deterministic", sql == sql2)

    # BUG FOUND IN BUILD: NULL modifiers made the detector silently miss the
    # exact violation it existed to catch.
    r = _rule(predicate={"type": "modifier_required", "code": "H0038",
                         "required_modifiers": ["HQ"]},
              machine_checkable=True, not_checkable_reason=None,
              required_claim_fields=["proc_cd", "mod_1"])
    sql = detector_gen.compile_rule(r.to_dict())
    check("modifier compiler is NULL-safe (COALESCE)", "COALESCE" in sql)


# ---------------------------------------------------------------- e2e

def test_end_to_end():
    print("\nend-to-end against the answer key")
    claims = synth_claims.build()

    specs = [
        ({"type": "max_units_per_day", "code": "H2015", "threshold": 16},
         ["proc_cd", "units"], "2023-07-01", {"C010", "C011"}),
        ({"type": "max_units_per_line", "code": "H2017", "threshold": 8},
         ["proc_cd", "units"], "2023-01-01", {"C020", "C055"}),
        ({"type": "modifier_required", "code": "H0038",
          "required_modifiers": ["HQ"]},
         ["proc_cd", "mod_1"], "2023-07-01", {"C030"}),
    ]
    for pred, fields, eff, expect in specs:
        r = _rule(predicate=pred, machine_checkable=True,
                  not_checkable_reason=None, required_claim_fields=fields,
                  effective_date=eff)
        dets = detector_gen.build_detectors([r.to_dict()])
        found, errs = run_detectors.run_all(dets, claims)
        got = set(found["claim_id"]) if "claim_id" in found.columns else set()
        check(f"{pred['type']} {pred['code']} flags {sorted(expect)}",
              bool(expect & got) and not errs, f"got {sorted(got)} errs={errs}")

    # nothing may ever flag the pre-effective-date claim
    r = _rule(predicate={"type": "max_units_per_day", "code": "H2015",
                         "threshold": 16},
              machine_checkable=True, not_checkable_reason=None,
              required_claim_fields=["proc_cd", "units"],
              effective_date="2023-07-01")
    dets = detector_gen.build_detectors([r.to_dict()])
    found, _ = run_detectors.run_all(dets, claims)
    got = set(found["claim_id"]) if "claim_id" in found.columns else set()
    check("pre-effective-date claim never flagged", "C050" not in got)


if __name__ == "__main__":
    test_schema()
    test_gate()
    test_compiler()
    test_end_to_end()
    print(f"\n{len(PASS)} passed, {len(FAIL)} failed")
    if FAIL:
        for f in FAIL:
            print("  FAILED:", f)
    sys.exit(1 if FAIL else 0)
