"""
Synthetic claims with PLANTED, KNOWN violations.

No PHI, and — more importantly — a known answer key. A detector demo where you
cannot prove the detector found the right rows is a screenshot, not evidence.
`EXPECTED` below is what a correct pipeline must flag.
"""
from __future__ import annotations

import pandas as pd

COLS = ["claim_id", "member_id", "provider_id", "provider_type", "proc_cd",
        "pos_cd", "units", "srvc_bgn_dt", "srvc_end_dt", "discharge_dt",
        "mod_1", "mod_2", "mod_3", "mod_4"]


def _c(cid, mem, prov, code, units, dos, pos="11", ptype="02",
       m1=None, m2=None, m3=None, m4=None):
    return dict(claim_id=cid, member_id=mem, provider_id=prov, provider_type=ptype,
                proc_cd=code, pos_cd=pos, units=units, srvc_bgn_dt=dos,
                srvc_end_dt=dos, discharge_dt=None,
                mod_1=m1, mod_2=m2, mod_3=m3, mod_4=m4)


def build() -> pd.DataFrame:
    rows = [
        # -- clean baseline -------------------------------------------------
        _c("C001", "M100", "P900", "H2015", 8, "2023-09-05"),
        _c("C002", "M101", "P900", "H2017", 4, "2023-09-05"),
        _c("C003", "M102", "P901", "H0038", 2, "2023-09-06", m1="HQ"),

        # -- V1: H2015 exceeds 16 units in one day (2 lines, 10 + 10) -------
        _c("C010", "M200", "P901", "H2015", 10, "2023-09-10"),
        _c("C011", "M200", "P901", "H2015", 10, "2023-09-10"),

        # -- V2: H2017 single line over MUE ceiling of 8 --------------------
        _c("C020", "M201", "P902", "H2017", 12, "2023-09-11"),

        # -- V3: H0038 billed without the required modifier -----------------
        _c("C030", "M202", "P902", "H0038", 4, "2023-09-12"),

        # -- V4: PTP pair 90834 + 90853 same member/day, modifier bypass ----
        _c("C040", "M203", "P903", "90834", 1, "2023-09-13"),
        _c("C041", "M203", "P903", "90853", 1, "2023-09-13", m1="59"),

        # -- pre-effective-date for BOTH the federal (2023-01-01) and state
        #    (2023-07-01) rules. No detector may flag this. -----------------
        _c("C050", "M204", "P904", "H2015", 20, "2022-11-01"),

        # -- BETWEEN the two effective dates. The federal MUE (eff 2023-01-01)
        #    must flag it; the state rule (eff 2023-07-01) must not. This is
        #    plane-relative date awareness, and it is worth showing. ---------
        _c("C055", "M206", "P906", "H2017", 12, "2023-03-15"),

        # -- H2025: ambiguous rule. Under >4 this is a violation; under >8 it
        #    is not. The KB must NOT auto-flag it either way. ----------------
        _c("C060", "M205", "P905", "H2025", 6, "2023-09-14"),
    ]
    return pd.DataFrame(rows, columns=COLS)


# Answer key: claim_ids a correct run must flag, by predicate.
EXPECTED = {
    "H2015 max_units_per_day > 16": {"C010", "C011"},   # collapses to one member/day row
    "H2017 max_units_per_line > 8": {"C020"},
    "H0038 modifier_required HQ": {"C030"},
    "90834 + 90853 code_pair_prohibited": {"C040"},
}

# Claims no detector may EVER flag.
MUST_NOT_FLAG = {
    "C050": "before every effective_date -- date guard must exclude",
    "C060": "H2025 is ambiguous -- must not be auto-flagged at all",
    "C001": "clean", "C002": "clean", "C003": "clean",
}

# Claims that must be flagged by federal rules only, not state rules.
# Proves effective dates are applied per-rule, not globally.
FEDERAL_ONLY_WINDOW = {
    "C055": {"must_flag_origin": "ncci", "must_not_flag_origin": "llm",
             "why": "DOS falls between the federal and state effective dates"},
}


def write_local(path: str) -> str:
    df = build()
    df.to_parquet(path, index=False)
    return path
