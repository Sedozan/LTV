"""
Pluggable LLM backend.

STUB    -- deterministic, no model. Runs the whole pipeline in seconds.
           Use this to build, test and rehearse the demo.
DBFM    -- Databricks Foundation Model serving endpoint (OpenAI-compatible).
           Verify the endpoint name in your workspace first; it is not
           guaranteed to be `databricks-gpt-oss-20b`.
HFLOCAL -- transformers on the cluster. 20B is CPU-feasible (slow).
           120B on CPU is not viable -- that was the multi-day run.

The extractor calls `complete_json()` and expects strict JSON back. Every
backend is responsible for returning parseable JSON or raising.
"""
from __future__ import annotations

import json
import re

import config


class LLMError(RuntimeError):
    pass


def _extract_json(text: str) -> dict | list:
    """Models wrap JSON in prose or fences. Recover the first balanced object."""
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start = min((i for i in (text.find("{"), text.find("[")) if i != -1), default=-1)
    if start == -1:
        raise LLMError(f"no JSON found in model output: {text[:200]!r}")
    opens, closes = {"{": "}", "[": "]"}, {"}": "{", "]": "["}
    stack, in_str, esc = [], False, False
    for i, ch in enumerate(text[start:], start):
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
        if in_str:
            continue
        if ch in opens:
            stack.append(ch)
        elif ch in closes:
            if not stack or stack[-1] != closes[ch]:
                break
            stack.pop()
            if not stack:
                return json.loads(text[start:i + 1])
    raise LLMError(f"unbalanced JSON in model output: {text[start:start+200]!r}")


# ---------------------------------------------------------------- backends

def _complete_dbfm(system: str, user: str) -> str:
    try:
        from openai import OpenAI
    except ImportError as e:
        raise LLMError("pip install openai  (Databricks serving is OpenAI-compatible)") from e
    import os
    host = os.environ.get("DATABRICKS_HOST", "").rstrip("/")
    token = os.environ.get("DATABRICKS_TOKEN", "")
    if not host or not token:
        raise LLMError("set DATABRICKS_HOST and DATABRICKS_TOKEN")
    client = OpenAI(api_key=token, base_url=f"{host}/serving-endpoints")
    resp = client.chat.completions.create(
        model=config.DBFM_ENDPOINT,
        messages=[{"role": "system", "content": system},
                  {"role": "user", "content": user}],
        max_tokens=config.LLM_MAX_TOKENS, temperature=config.LLM_TEMPERATURE)
    return resp.choices[0].message.content


_hf = {}


def _complete_hflocal(system: str, user: str) -> str:
    if "pipe" not in _hf:
        from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
        tok = AutoTokenizer.from_pretrained(config.HF_MODEL)
        mdl = AutoModelForCausalLM.from_pretrained(config.HF_MODEL, device_map="auto")
        _hf["pipe"] = pipeline("text-generation", model=mdl, tokenizer=tok)
    prompt = f"<|system|>\n{system}\n<|user|>\n{user}\n<|assistant|>\n"
    out = _hf["pipe"](prompt, max_new_tokens=config.LLM_MAX_TOKENS,
                      do_sample=False, return_full_text=False)
    return out[0]["generated_text"]


def _complete_stub(system: str, user: str) -> str:
    """Deterministic fake extraction driven by simple cues in the section text.

    This is NOT an extractor. It exists so the pipeline, the validation gate,
    the detector compiler and the demo can be exercised end-to-end without
    waiting on inference. Swap to DBFM/HFLOCAL for real extraction.
    """
    import stub_extractions
    return json.dumps(stub_extractions.for_section(user))


_BACKENDS = {"STUB": _complete_stub, "DBFM": _complete_dbfm, "HFLOCAL": _complete_hflocal}


def complete_json(system: str, user: str) -> dict | list:
    backend = _BACKENDS.get(config.LLM_BACKEND)
    if backend is None:
        raise LLMError(f"unknown LLM_BACKEND: {config.LLM_BACKEND}")
    return _extract_json(backend(system, user))


def backend_name() -> str:
    return config.LLM_BACKEND
