"""
The manual gold set: hand-transcribed, human-verified rules.

>>> READ THIS BEFORE THE DEMO <<<
Every rule below has a `verified` flag. Rules ship with verified=False as
SCAFFOLD -- correct structure, placeholder content. You must replace the
content with your own transcriptions from the source slides and flip the
flag. `benchmark.py` refuses to score against unverified rules, on purpose:
a benchmark you did not verify is not a benchmark, it is a second guess.

The H2025 entry is the exception worth keeping: the dual threshold
(>8 on one slide, >4 on another) came from your own reading of the source
deck, and it is the single best demo artifact you have -- it shows the KB
preserving a real contradiction instead of silently picking a side.
"""
from __future__ import annotations

from schema import Rule

SRC = "AHCCCS DFSM Outpatient BH Billing Codes training deck (July 2023)"


def _r(**kw) -> Rule:
    verified = kw.pop("verified", False)
    r = Rule(origin="manual", source_doc=SRC, **kw)
    r.notes = (r.notes + " | verified=" + str(verified)).strip(" |")
    return r.assign_id()


GOLD: list[Rule] = [

    # ---- the ambiguity case. Keep this one. It is the demo. ----------------
    _r(
        plane="coverage_scope",
        binding_status="guidance",
        statement=("H2025 daily unit ceiling is stated inconsistently in the "
                   "source deck: one slide says more than 8, another says more than 4."),
        predicate={"type": "max_units_per_day", "code": "H2025", "threshold": None},
        codes=["H2025"],
        population="bh_outpatient",
        machine_checkable=False,
        not_checkable_reason="ambiguous_source",
        ambiguity_flag=True,
        ambiguity_note=("Source contradicts itself. Do NOT collapse. "
                        "Route to policy owner for written clarification."),
        alternates=[
            {"threshold": 8, "locator": "slide 11", "reading": "units > 8 flagged"},
            {"threshold": 4, "locator": "slide 14", "reading": "units > 4 flagged"},
        ],
        source_locator="slides 11 and 14",
        effective_date="2023-07-01",
        verified=True,
    ),

    # ---- SCAFFOLD below: replace content, then set verified=True -----------
    _r(
        plane="coverage_scope",
        binding_status="guidance",
        statement="SCAFFOLD: <code> is limited to <N> units per day.",
        predicate={"type": "max_units_per_day", "code": "H2015", "threshold": 16},
        codes=["H2015"],
        population="bh_outpatient",
        machine_checkable=True,
        required_claim_fields=["proc_cd", "units", "srvc_bgn_dt", "member_id"],
        source_locator="slide TBD",
        effective_date="2023-07-01",
        notes="SCAFFOLD -- replace threshold with verified value from source slide.",
        verified=False,
    ),
    _r(
        plane="coverage_scope",
        binding_status="guidance",
        statement="SCAFFOLD: <code> requires modifier <M> when billed by <provider type>.",
        predicate={"type": "modifier_required", "code": "H0038",
                   "required_modifiers": ["HQ"]},
        codes=["H0038"],
        population="bh_outpatient",
        machine_checkable=True,
        required_claim_fields=["proc_cd", "mod_1", "mod_2", "mod_3", "mod_4"],
        source_locator="slide TBD",
        effective_date="2023-07-01",
        notes="SCAFFOLD -- confirm which modifier and which provider types.",
        verified=False,
    ),
    _r(
        plane="coverage_scope",
        binding_status="guidance",
        statement="SCAFFOLD: <code> is payable only in place-of-service <POS list>.",
        predicate={"type": "pos_allowed", "code": "H2017", "allowed_pos": ["11", "53"]},
        codes=["H2017"],
        population="bh_outpatient",
        machine_checkable=True,
        required_claim_fields=["proc_cd", "pos_cd"],
        source_locator="slide TBD",
        effective_date="2023-07-01",
        notes="SCAFFOLD -- confirm allowed POS list.",
        verified=False,
    ),

    # ---- an intentionally un-mechanizable rule. Demonstrates guardrail #1. --
    _r(
        plane="enforcement",
        binding_status="state_policy",
        statement=("Provider must document medical necessity in the member record "
                   "for each billed encounter."),
        predicate={"type": "not_checkable", "reason": "requires_medical_record"},
        codes=[],
        population="bh_outpatient",
        machine_checkable=False,
        not_checkable_reason="requires_medical_record",
        source_locator="AMPM policy reference TBD",
        notes=("Deliberately un-mechanizable. Routes to documentation-review lead, "
               "never an automated finding. This is the enforcement plane."),
        verified=False,
    ),
]


def verified_gold() -> list[Rule]:
    return [r for r in GOLD if "verified=True" in r.notes]


def unverified_count() -> int:
    return len(GOLD) - len(verified_gold())
