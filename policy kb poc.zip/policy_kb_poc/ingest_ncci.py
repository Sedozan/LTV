"""
NCCI ingest -- the coding-edit floor.

NCCI is a DOWNLOAD, not an extraction target. ACA 6507 (amending SSA 1903(r))
requires states to apply compatible NCCI methodologies to Medicaid claims, and
CMS guidance applies them BEFORE state edits (more-restrictive-wins on conflict).
CMS publishes the complete Medicaid PTP and MUE files quarterly as Excel /
tab-delimited replacements.

So: no LLM here. A file read, a filter, a mapping into Rule objects.

Get the files:
  https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files
  Contractors use these PUBLIC files. The operative state files live on RISSNET
  and are state-staff only -- confirm your entitlement before the demo.

Column names shift between quarters, so detection is fuzzy. ALWAYS eyeball the
`--inspect` output against the real file before trusting a run.
"""
from __future__ import annotations

import argparse
import os
import sys

import pandas as pd

import config
from schema import Rule

# ---------------------------------------------------------------- helpers

def _norm(s: str) -> str:
    return "".join(ch for ch in str(s).lower() if ch.isalnum())


def _find_col(df: pd.DataFrame, *candidates: str) -> str | None:
    norm = {_norm(c): c for c in df.columns}
    for cand in candidates:
        n = _norm(cand)
        if n in norm:
            return norm[n]
    for cand in candidates:                      # substring fallback
        n = _norm(cand)
        for k, orig in norm.items():
            if n in k:
                return orig
    return None


def _read_any(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    if path.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(path)
    return pd.read_csv(path, sep="\t" if path.lower().endswith(".txt") else ",")


def _iso(v) -> str | None:
    if pd.isna(v) or v in ("", "*", "20991231"):
        return None
    try:
        return pd.to_datetime(str(v)).date().isoformat()
    except Exception:
        return None


# ---------------------------------------------------------------- MUE

def load_mue(path: str, code_filter: list[str] | None = None) -> list[Rule]:
    """MUE -> max_units_per_line rules. Unit ceiling per code, per line."""
    df = _read_any(path)
    c_code = _find_col(df, "hcpcs cpt code", "hcpcs/cpt code", "procedure code", "code")
    c_val = _find_col(df, "mue value", "practitioner services mue values", "mue")
    c_eff = _find_col(df, "effective date", "mue effective date")
    if not c_code or not c_val:
        raise ValueError(f"Could not find code/value columns. Saw: {list(df.columns)}")

    rules: list[Rule] = []
    for _, row in df.iterrows():
        code = str(row[c_code]).strip().upper()
        if code_filter and code not in code_filter:
            continue
        try:
            val = int(float(row[c_val]))
        except (ValueError, TypeError):
            continue
        r = Rule(
            origin="ncci", plane="coding_edit", binding_status="mandatory",
            statement=f"NCCI MUE: {code} maximum {val} unit(s) of service per line.",
            predicate={"type": "max_units_per_line", "code": code, "threshold": val},
            codes=[code], population="all",
            machine_checkable=True,
            required_claim_fields=["proc_cd", "units"],
            source_doc="CMS Medicaid NCCI MUE (Practitioner Services)",
            source_locator=f"MUE table row for {code}",
            source_url="https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files",
            doc_version=os.path.basename(path),
            effective_date=_iso(row[c_eff]) if c_eff else None,
            notes="Federal floor (ACA 6507). AZ may be stricter, never looser.",
        ).assign_id()
        rules.append(r)
    return rules


# ---------------------------------------------------------------- PTP

def load_ptp(path: str, code_filter: list[str] | None = None) -> list[Rule]:
    """PTP -> code_pair_prohibited rules.

    modifier_indicator: 0 = modifier cannot bypass, 1 = a modifier may bypass,
    9 = edit not applicable. We keep 0 and 1 and carry the indicator, because
    indicator-1 pairs are exactly where modifier-bypass abuse lives.
    """
    df = _read_any(path)
    c1 = _find_col(df, "column 1", "column1", "comprehensive code")
    c2 = _find_col(df, "column 2", "column2", "component code")
    c_mod = _find_col(df, "modifier indicator", "modifier", "ptp modifier indicator")
    c_eff = _find_col(df, "effective date", "ptp edit effective date")
    c_del = _find_col(df, "deletion date", "termination date")
    if not c1 or not c2:
        raise ValueError(f"Could not find column1/column2. Saw: {list(df.columns)}")

    rules: list[Rule] = []
    for _, row in df.iterrows():
        a, b = str(row[c1]).strip().upper(), str(row[c2]).strip().upper()
        if code_filter and a not in code_filter and b not in code_filter:
            continue
        mi = str(row[c_mod]).strip()[:1] if c_mod else "9"
        if mi == "9":
            continue
        if c_del and _iso(row[c_del]):
            continue                                  # deleted edit
        r = Rule(
            origin="ncci", plane="coding_edit", binding_status="mandatory",
            statement=(f"NCCI PTP: {b} should not be reported with {a} "
                       f"(modifier indicator {mi})."),
            predicate={"type": "code_pair_prohibited", "code_a": a, "code_b": b,
                       "modifier_indicator": mi},
            codes=[a, b], population="all",
            machine_checkable=True,
            required_claim_fields=["proc_cd", "member_id", "srvc_bgn_dt",
                                   "mod_1", "mod_2", "mod_3", "mod_4"],
            source_doc="CMS Medicaid NCCI PTP (Practitioner Services)",
            source_locator=f"PTP pair {a}/{b}",
            source_url="https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files",
            doc_version=os.path.basename(path),
            effective_date=_iso(row[c_eff]) if c_eff else None,
            notes=("Modifier indicator 1 = a modifier may bypass this edit. "
                   "Bypass on indicator-1 pairs is the enforcement-gap signal."),
        ).assign_id()
        rules.append(r)
    return rules


# ---------------------------------------------------------------- demo data

def sample_files(dirpath: str) -> tuple[str, str]:
    """Write small stand-in MUE/PTP files so the POC runs before you have
    the real downloads. Values are ILLUSTRATIVE, not real NCCI values."""
    os.makedirs(dirpath, exist_ok=True)
    mue = pd.DataFrame({
        "HCPCS/CPT Code": ["H2015", "H2017", "H2019", "H0038", "90834", "90853"],
        "Practitioner Services MUE Values": [16, 8, 8, 8, 1, 1],
        "MUE Effective Date": ["2023-01-01"] * 6,
    })
    ptp = pd.DataFrame({
        "Column 1": ["90834", "H2015", "90837"],
        "Column 2": ["90853", "H2017", "90834"],
        "Modifier Indicator": [1, 1, 0],
        "PTP Edit Effective Date": ["2023-01-01"] * 3,
        "Deletion Date": ["", "", ""],
    })
    p_mue = os.path.join(dirpath, "ncci_mue_practitioner.xlsx")
    p_ptp = os.path.join(dirpath, "ncci_ptp_practitioner.xlsx")
    mue.to_excel(p_mue, index=False)
    ptp.to_excel(p_ptp, index=False)
    return p_mue, p_ptp


def ingest(mue_path: str | None = None, ptp_path: str | None = None,
           code_filter: list[str] | None = None) -> list[Rule]:
    code_filter = code_filter if code_filter is not None else config.POC_CODE_SET
    out: list[Rule] = []
    if mue_path and os.path.exists(mue_path):
        out += load_mue(mue_path, code_filter)
    if ptp_path and os.path.exists(ptp_path):
        out += load_ptp(ptp_path, code_filter)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--inspect", metavar="FILE",
                    help="print detected columns for a real NCCI file")
    ap.add_argument("--make-sample", metavar="DIR",
                    help="write illustrative stand-in files")
    a = ap.parse_args()
    if a.make_sample:
        print("wrote:", *sample_files(a.make_sample), sep="\n  ")
        sys.exit(0)
    if a.inspect:
        d = _read_any(a.inspect)
        print("rows:", len(d))
        print("columns:", list(d.columns))
        print(d.head(5).to_string())
        sys.exit(0)
    ap.print_help()
