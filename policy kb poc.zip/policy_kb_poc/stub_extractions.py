"""
Stub extractions for STUB mode.

Cue-driven, deterministic, obviously fake. The point is to exercise the
pipeline (validation gate, ambiguity handling, detector compilation, benchmark)
without inference latency. Includes deliberate defects -- a malformed code and
an over-claimed machine_checkable -- so you can watch the validation gate
reject them during the demo. That rejection is a feature to show, not hide.
"""
from __future__ import annotations

import re

_HITS = {
    "H2015": {"threshold": 16, "kind": "units"},
    "H2017": {"threshold": 8, "kind": "units"},
    "H0038": {"kind": "modifier", "modifiers": ["HQ"]},
    "H2025": {"kind": "ambiguous"},
}


def for_section(section_text: str) -> list[dict]:
    """Return a list of raw extraction dicts for one document section."""
    out: list[dict] = []
    codes = set(re.findall(r"\b[A-Z]\d{4}\b", section_text))

    for code in sorted(codes):
        hit = _HITS.get(code)
        if not hit:
            continue

        if hit["kind"] == "units":
            out.append({
                "statement": f"{code} is limited to {hit['threshold']} units per day.",
                "predicate": {"type": "max_units_per_day", "code": code,
                              "threshold": hit["threshold"]},
                "codes": [code], "plane": "coverage_scope",
                "binding_status": "guidance", "population": "bh_outpatient",
                "machine_checkable": True,
                "required_claim_fields": ["proc_cd", "units", "srvc_bgn_dt", "member_id"],
                "effective_date": "2023-07-01",
            })

        elif hit["kind"] == "modifier":
            out.append({
                "statement": f"{code} requires modifier {hit['modifiers'][0]}.",
                "predicate": {"type": "modifier_required", "code": code,
                              "required_modifiers": hit["modifiers"]},
                "codes": [code], "plane": "coverage_scope",
                "binding_status": "guidance", "population": "bh_outpatient",
                "machine_checkable": True,
                "required_claim_fields": ["proc_cd", "mod_1", "mod_2", "mod_3", "mod_4"],
                "effective_date": "2023-07-01",
            })

        elif hit["kind"] == "ambiguous":
            # The real contradiction from the source deck.
            out.append({
                "statement": (f"{code} daily unit ceiling stated inconsistently "
                              f"across slides."),
                "predicate": {"type": "max_units_per_day", "code": code,
                              "threshold": None},
                "codes": [code], "plane": "coverage_scope",
                "binding_status": "guidance", "population": "bh_outpatient",
                "machine_checkable": False,
                "not_checkable_reason": "ambiguous_source",
                "ambiguity_flag": True,
                "ambiguity_note": "Slide 11 says >8; slide 14 says >4. Not collapsed.",
                "alternates": [{"threshold": 8, "locator": "slide 11"},
                               {"threshold": 4, "locator": "slide 14"}],
                "effective_date": "2023-07-01",
            })

    # ---- deliberate defects, so the gate has something to catch -------------
    if "medical necessity" in section_text.lower():
        out.append({
            "statement": "Provider must document medical necessity for each encounter.",
            "predicate": {"type": "not_checkable", "reason": "requires_medical_record"},
            "codes": [], "plane": "enforcement", "binding_status": "state_policy",
            "population": "bh_outpatient",
            "machine_checkable": True,          # DEFECT: over-claimed
            "required_claim_fields": [],
        })
    if "prior authorization" in section_text.lower():
        out.append({
            "statement": "Prior authorization required for H99999 services.",
            "predicate": {"type": "max_units_per_day", "code": "H99999", "threshold": 1},
            "codes": ["H99999"],                # DEFECT: malformed code
            "plane": "coverage_scope", "binding_status": "guidance",
            "population": "bh_outpatient", "machine_checkable": True,
            "required_claim_fields": ["proc_cd", "units"],
        })
    return out
