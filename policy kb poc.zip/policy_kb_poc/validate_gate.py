"""
The validation gate. Nothing enters the KB without passing here.

Responsibilities:
  1. Schema validation (schema.validate)
  2. Consistency repair where it is SAFE and mechanical
  3. Ambiguity enforcement -- ambiguous rules are forced non-checkable
  4. Cross-plane conflict detection (NCCI floor vs AHCCCS overlay)
  5. Near-duplicate collapse, authority-aware

What it deliberately does NOT do: guess a missing threshold, pick between
contradictory readings, or infer an effective date. Those go to a human.
"""
from __future__ import annotations

from dataclasses import replace

from schema import Rule, validate, BINDING_RANK

STATUS_CLEAN = "clean"
STATUS_PATCHED = "patched"
STATUS_REVIEW = "needs_review"
STATUS_QUARANTINED = "quarantined"


def _patch(rule: Rule) -> tuple[Rule, list[str]]:
    """Safe, mechanical repairs only."""
    notes: list[str] = []

    # Ambiguity always wins over a checkable claim.
    if rule.ambiguity_flag and rule.machine_checkable:
        rule.machine_checkable = False
        rule.not_checkable_reason = "ambiguous_source"
        notes.append("forced machine_checkable=False (ambiguous source)")

    # not_checkable predicate cannot be checkable.
    if rule.predicate.get("type") == "not_checkable" and rule.machine_checkable:
        rule.machine_checkable = False
        rule.not_checkable_reason = (rule.predicate.get("reason")
                                     or "no_claim_field")
        notes.append("forced machine_checkable=False (not_checkable predicate)")

    # A null threshold cannot be mechanized.
    if (rule.predicate.get("type", "").startswith("max_units")
            and rule.predicate.get("threshold") in (None, "")):
        if rule.machine_checkable:
            rule.machine_checkable = False
            rule.not_checkable_reason = rule.not_checkable_reason or "ambiguous_source"
            notes.append("forced machine_checkable=False (null threshold)")

    # Enforcement plane is never auto-checkable.
    if rule.plane == "enforcement" and rule.machine_checkable:
        rule.machine_checkable = False
        rule.not_checkable_reason = "process_obligation"
        notes.append("forced machine_checkable=False (enforcement plane)")

    # Missing reason on a non-checkable rule.
    if not rule.machine_checkable and not rule.not_checkable_reason:
        rule.not_checkable_reason = "no_claim_field"
        notes.append("defaulted not_checkable_reason=no_claim_field")

    # Codes should be uppercase and de-duplicated.
    up = sorted({c.strip().upper() for c in rule.codes})
    if up != rule.codes:
        rule.codes = up
        notes.append("normalized codes")

    return rule, notes


def gate(rules: list[Rule]) -> tuple[list[dict], list[dict]]:
    """Returns (accepted_rows, rejected_rows)."""
    accepted, rejected = [], []

    for r in rules:
        r, patch_notes = _patch(r)
        errs = validate(r)
        r.assign_id()  # re-hash after patching

        if errs:
            row = r.to_dict()
            row["validation_status"] = STATUS_QUARANTINED
            row["validation_errors"] = "; ".join(errs)
            rejected.append(row)
            continue

        row = r.to_dict()
        if r.ambiguity_flag:
            row["validation_status"] = STATUS_REVIEW
        elif patch_notes:
            row["validation_status"] = STATUS_PATCHED
        else:
            row["validation_status"] = STATUS_CLEAN
        row["validation_errors"] = ""
        row["patch_notes"] = "; ".join(patch_notes)
        accepted.append(row)

    accepted = _collapse_duplicates(accepted)
    return accepted, rejected


def _collapse_duplicates(rows: list[dict]) -> list[dict]:
    """Same plane + same predicate = same rule. Keep the higher authority.

    NCCI (mandatory) beats an AHCCCS restatement of the same edit. The loser is
    kept as a cross-reference, not deleted -- the restatement is still the
    citation an investigator wants to see.
    """
    best: dict[tuple, dict] = {}
    for row in rows:
        pred = row["predicate"]
        key = (row["plane"], pred.get("type"), pred.get("code"),
               pred.get("code_a"), pred.get("code_b"),
               str(pred.get("threshold")), row["population"])
        cur = best.get(key)
        if cur is None:
            best[key] = row
            continue
        if BINDING_RANK.get(row["binding_status"], 9) < \
           BINDING_RANK.get(cur["binding_status"], 9):
            row["notes"] = (row.get("notes", "") +
                            f" | supersedes restatement {cur['rule_id']}").strip(" |")
            row["supersedes"] = cur["rule_id"]
            best[key] = row
        else:
            cur["notes"] = (cur.get("notes", "") +
                            f" | restated by {row['rule_id']}").strip(" |")
    return list(best.values())


def conflict_report(rows: list[dict]) -> list[dict]:
    """Same code + same predicate type, different thresholds, across sources.

    Under ACA 6507 the more restrictive value governs on the coding-edit plane.
    We report; we do not silently apply.
    """
    by_code: dict[tuple, list[dict]] = {}
    for r in rows:
        p = r["predicate"]
        if not str(p.get("type", "")).startswith("max_units"):
            continue
        if p.get("threshold") in (None, ""):
            continue
        by_code.setdefault((p.get("code"), r["population"]), []).append(r)

    out = []
    for (code, pop), group in by_code.items():
        vals = {float(g["predicate"]["threshold"]) for g in group}
        if len(vals) > 1:
            strictest = min(group, key=lambda g: float(g["predicate"]["threshold"]))
            out.append({
                "code": code, "population": pop,
                "thresholds": sorted(vals),
                "sources": [f"{g['origin']}:{g['binding_status']}:{g['rule_id']}"
                            for g in group],
                "governing_rule_id": strictest["rule_id"],
                "resolution": "more-restrictive governs (ACA 6507); human confirm",
            })
    return out
