"""
Two analyses that make the KB defensible.

1. gap_analysis   -- NCCI floor vs AHCCCS overlay. Where is the state silent
                     relative to the federal edit set? That silence is where
                     modifier bypass and unit overage live. This is the
                     OIG-differentiated output.

2. benchmark      -- LLM extraction vs the human-verified gold set.
                     Refuses to score against unverified gold, on purpose.
"""
from __future__ import annotations

import pandas as pd

import config
from gold_set import verified_gold, unverified_count


# ---------------------------------------------------------------- gap

def gap_analysis(rules: list[dict], code_set: list[str] | None = None
                 ) -> pd.DataFrame:
    code_set = code_set or config.POC_CODE_SET
    ncci_codes, state_codes = {}, {}

    for r in rules:
        for c in (r.get("codes") or []):
            if r["origin"] == "ncci":
                ncci_codes.setdefault(c, []).append(r["rule_id"])
            else:
                state_codes.setdefault(c, []).append(r["rule_id"])

    rows = []
    for code in sorted(set(code_set) | set(ncci_codes) | set(state_codes)):
        has_fed = code in ncci_codes
        has_state = code in state_codes
        if has_fed and has_state:
            status, risk = "both", "covered"
        elif has_fed and not has_state:
            status, risk = "federal_only", "STATE SILENT -- exploit surface"
        elif has_state and not has_fed:
            status, risk = "state_only", "state-specific; no federal floor"
        else:
            status, risk = "neither", "UNGOVERNED -- no rule either source"
        rows.append({
            "code": code, "coverage": status, "risk": risk,
            "ncci_rules": len(ncci_codes.get(code, [])),
            "state_rules": len(state_codes.get(code, [])),
            "ncci_rule_ids": ",".join(ncci_codes.get(code, [])),
            "state_rule_ids": ",".join(state_codes.get(code, [])),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- benchmark

def _sig(rule_like) -> tuple:
    p = rule_like["predicate"] if isinstance(rule_like, dict) else rule_like.predicate
    codes = rule_like["codes"] if isinstance(rule_like, dict) else rule_like.codes
    return (p.get("type"), p.get("code") or (codes[0] if codes else None),
            str(p.get("threshold")))


def benchmark(extracted: list[dict]) -> dict:
    """Precision/recall of extraction against VERIFIED gold rules only."""
    gold = verified_gold()
    skipped = unverified_count()

    if not gold:
        return {"status": "NO_VERIFIED_GOLD",
                "message": ("Every gold rule is still scaffold. Transcribe and "
                            "verify at least a few before claiming accuracy."),
                "unverified_skipped": skipped}

    gold_sigs = {_sig(g) for g in gold}
    ext_sigs = {_sig(e) for e in extracted}

    tp = gold_sigs & ext_sigs
    fn = gold_sigs - ext_sigs
    fp = ext_sigs - gold_sigs

    prec = len(tp) / (len(tp) + len(fp)) if (tp or fp) else 0.0
    rec = len(tp) / (len(tp) + len(fn)) if (tp or fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0

    return {"status": "SCORED", "gold_verified": len(gold),
            "unverified_skipped": skipped,
            "true_positives": len(tp), "false_positives": len(fp),
            "false_negatives": len(fn),
            "precision": round(prec, 3), "recall": round(rec, 3),
            "f1": round(f1, 3),
            "missed": [list(s) for s in sorted(fn, key=str)]}


# ---------------------------------------------------------------- kb summary

def kb_summary(rules: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(rules)
    if df.empty:
        return df
    g = (df.groupby(["plane", "origin", "binding_status"])
           .agg(rules=("rule_id", "count"),
                machine_checkable=("machine_checkable", "sum"),
                ambiguous=("ambiguity_flag", "sum"))
           .reset_index())
    return g
