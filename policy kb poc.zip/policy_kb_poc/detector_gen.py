"""
Detector generation: rule object -> SQL.

THE POINT OF THIS FILE: because the KB ships a CLOSED predicate grammar, the
common case compiles DETERMINISTICALLY. No LLM. The SQL is provably the same
every run, reviewable by a human once per predicate type, and impossible to
hallucinate a threshold into.

The LLM path exists only as a cross-check for the demo: generate the same
detector with an LLM, diff the flagged claim sets, and show they agree. That
agreement is the trust argument. If they disagree, the compiler wins.

Rules with machine_checkable=False are NEVER compiled. They emit a
documentation-review lead instead.
"""
from __future__ import annotations

import json

import config

C = config.CLAIM_COLS


def _lit(v) -> str:
    return "'" + str(v).replace("'", "''") + "'"


def _in_list(vals) -> str:
    return ", ".join(_lit(v) for v in vals)


def _date_guard(effective_date, alias: str = "c") -> str:
    if not effective_date:
        return "1=1"
    return f"CAST({alias}.{C['dos']} AS DATE) >= DATE {_lit(effective_date)}"


def _mods(alias: str = "c") -> list[str]:
    return [f"{alias}.{m}" for m in C["mods"]]


# ---------------------------------------------------------------- compilers

def _max_units_per_line(p, rule, table):
    return f"""
SELECT c.{C['claim']} AS claim_id, c.{C['member']} AS member_id,
       c.{C['provider']} AS provider_id, c.{C['dos']} AS dos,
       c.{C['code']} AS code, c.{C['units']} AS observed_units,
       {p['threshold']} AS allowed_units
FROM {table} c
WHERE c.{C['code']} = {_lit(p['code'])}
  AND c.{C['units']} > {p['threshold']}
  AND {_date_guard(rule.get('effective_date'))}
""".strip()


def _max_units_per_day(p, rule, table):
    return f"""
SELECT MIN(c.{C['claim']}) AS claim_id, c.{C['member']} AS member_id,
       MIN(c.{C['provider']}) AS provider_id, c.{C['dos']} AS dos,
       c.{C['code']} AS code, SUM(c.{C['units']}) AS observed_units,
       {p['threshold']} AS allowed_units
FROM {table} c
WHERE c.{C['code']} = {_lit(p['code'])}
  AND {_date_guard(rule.get('effective_date'))}
GROUP BY c.{C['member']}, c.{C['dos']}, c.{C['code']}
HAVING SUM(c.{C['units']}) > {p['threshold']}
""".strip()


def _code_pair_prohibited(p, rule, table):
    bypass = " OR ".join(
        f"COALESCE(b.{m}, '') IN ('59','XE','XP','XS','XU')" for m in C["mods"])
    return f"""
SELECT a.{C['claim']} AS claim_id, a.{C['member']} AS member_id,
       a.{C['provider']} AS provider_id, a.{C['dos']} AS dos,
       {_lit(p['code_a'] + ' + ' + p['code_b'])} AS code,
       1 AS observed_units, 0 AS allowed_units,
       CASE WHEN {bypass} THEN 1 ELSE 0 END AS modifier_bypass_used
FROM {table} a
JOIN {table} b
  ON a.{C['member']} = b.{C['member']}
 AND a.{C['dos']} = b.{C['dos']}
 AND a.{C['claim']} <> b.{C['claim']}
WHERE a.{C['code']} = {_lit(p['code_a'])}
  AND b.{C['code']} = {_lit(p['code_b'])}
  AND {_date_guard(rule.get('effective_date'), 'a')}
""".strip()


def _pos_allowed(p, rule, table):
    # COALESCE: a NULL pos_cd must count as "not in the allowed list", not as
    # UNKNOWN. Without this, NOT IN yields NULL and the row silently escapes.
    return f"""
SELECT c.{C['claim']} AS claim_id, c.{C['member']} AS member_id,
       c.{C['provider']} AS provider_id, c.{C['dos']} AS dos,
       c.{C['code']} AS code, c.{C['units']} AS observed_units,
       0 AS allowed_units, c.{C['pos']} AS observed_pos
FROM {table} c
WHERE c.{C['code']} = {_lit(p['code'])}
  AND COALESCE(c.{C['pos']}, '') NOT IN ({_in_list(p['allowed_pos'])})
  AND {_date_guard(rule.get('effective_date'))}
""".strip()


def _modifier_required(p, rule, table):
    # SQL three-valued logic hazard: `mod_1 IN ('HQ')` is NULL when mod_1 is
    # NULL, so NOT(...) is NULL and a claim MISSING the required modifier --
    # exactly the violation -- would never be flagged. COALESCE makes absence
    # behave as absence. This is the highest-value line in the file.
    present = " OR ".join(
        f"COALESCE(c.{m}, '') IN ({_in_list(p['required_modifiers'])})"
        for m in C["mods"])
    return f"""
SELECT c.{C['claim']} AS claim_id, c.{C['member']} AS member_id,
       c.{C['provider']} AS provider_id, c.{C['dos']} AS dos,
       c.{C['code']} AS code, c.{C['units']} AS observed_units,
       0 AS allowed_units
FROM {table} c
WHERE c.{C['code']} = {_lit(p['code'])}
  AND NOT ({present})
  AND {_date_guard(rule.get('effective_date'))}
""".strip()


def _frequency_limit(p, rule, table):
    return f"""
SELECT MIN(c.{C['claim']}) AS claim_id, c.{C['member']} AS member_id,
       MIN(c.{C['provider']}) AS provider_id,
       MIN(c.{C['dos']}) AS dos, c.{C['code']} AS code,
       COUNT(*) AS observed_units, {p['max_count']} AS allowed_units
FROM {table} c
WHERE c.{C['code']} = {_lit(p['code'])}
  AND {_date_guard(rule.get('effective_date'))}
GROUP BY c.{C['member']}, c.{C['code']}
HAVING COUNT(*) > {p['max_count']}
""".strip()


def _provider_type_allowed(p, rule, table):
    return f"""
SELECT c.{C['claim']} AS claim_id, c.{C['member']} AS member_id,
       c.{C['provider']} AS provider_id, c.{C['dos']} AS dos,
       c.{C['code']} AS code, c.{C['units']} AS observed_units,
       0 AS allowed_units
FROM {table} c
WHERE c.{C['code']} = {_lit(p['code'])}
  AND COALESCE(c.{C['provider_type']}, '') NOT IN ({_in_list(p['allowed_provider_types'])})
  AND {_date_guard(rule.get('effective_date'))}
""".strip()


COMPILERS = {
    "max_units_per_line": _max_units_per_line,
    "max_units_per_day": _max_units_per_day,
    "code_pair_prohibited": _code_pair_prohibited,
    "pos_allowed": _pos_allowed,
    "modifier_required": _modifier_required,
    "frequency_limit": _frequency_limit,
    "provider_type_allowed": _provider_type_allowed,
}


class NotCompilable(Exception):
    pass


def compile_rule(rule: dict, table: str | None = None) -> str:
    """Deterministic. Same rule in, same SQL out, forever."""
    table = table or config.CLAIMS_TABLE
    if not rule.get("machine_checkable"):
        raise NotCompilable(
            f"{rule['rule_id']} is not machine_checkable "
            f"({rule.get('not_checkable_reason')}) -- emit a review lead, not SQL")
    p = rule["predicate"]
    if isinstance(p, str):
        p = json.loads(p)
    fn = COMPILERS.get(p.get("type"))
    if fn is None:
        raise NotCompilable(f"no compiler for predicate type {p.get('type')!r}")
    return fn(p, rule, table)


def build_detectors(rules: list[dict], table: str | None = None) -> list[dict]:
    """Returns one row per rule: compiled SQL, or the reason it was not compiled."""
    out = []
    for r in rules:
        row = {
            "rule_id": r["rule_id"], "plane": r["plane"],
            "binding_status": r["binding_status"], "statement": r["statement"],
            "source_doc": r["source_doc"], "source_locator": r["source_locator"],
            "effective_date": r.get("effective_date"),
            "machine_checkable": r.get("machine_checkable", False),
        }
        try:
            row["sql"] = compile_rule(r, table)
            row["compiled"] = True
            row["disposition"] = "automated_detector"
            row["skip_reason"] = ""
        except NotCompilable as e:
            row["sql"] = ""
            row["compiled"] = False
            row["disposition"] = ("review_lead" if not r.get("machine_checkable")
                                  else "unsupported_predicate")
            row["skip_reason"] = str(e)
        out.append(row)
    return out


# ---------------------------------------------------------------- LLM cross-check

LLM_SYSTEM = """You translate ONE structured billing rule into a single SQL query.

You are a translator, not an interpreter. Every value you need is already in
the rule object. Do not invent thresholds, codes, dates or columns. If a value
is null, refuse and return the string REFUSE.

Return ONLY {"sql": "..."} as JSON. Dialect: ANSI SQL.
"""


def compile_rule_llm(rule: dict, table: str | None = None) -> str:
    """Cross-check path. Used in the demo to show it agrees with the compiler."""
    from llm_client import complete_json
    table = table or config.CLAIMS_TABLE
    payload = {
        "rule": {k: rule[k] for k in ("rule_id", "statement", "predicate",
                                      "effective_date", "machine_checkable")
                 if k in rule},
        "claims_table": table,
        "columns": C,
    }
    resp = complete_json(LLM_SYSTEM, json.dumps(payload, indent=2, default=str))
    return resp.get("sql", "") if isinstance(resp, dict) else ""
