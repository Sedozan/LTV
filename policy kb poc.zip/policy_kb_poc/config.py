"""
POC configuration. Everything env-specific lives here.

Run modes
---------
LOCAL      : parquet + duckdb. No Databricks needed. Use to build/demo.
DATABRICKS : Delta + Unity Catalog + Spark. Use for the client demo on-platform.
"""
import os

# ---------------------------------------------------------------- run mode
MODE = os.environ.get("PKB_MODE", "LOCAL")  # LOCAL | DATABRICKS

# ---------------------------------------------------------------- storage
# Databricks (3-part Unity Catalog names -- unify these, do not use bare 2-part)
CATALOG = os.environ.get("PKB_CATALOG", "main")
SCHEMA = os.environ.get("PKB_SCHEMA", "policy_kb")

TABLES = {
    "rules": "policy_rules",              # the KB asset -- rule objects
    "rules_rejected": "policy_rules_rejected",
    "detectors": "policy_detectors",      # generated SQL, one row per rule
    "findings": "policy_findings",        # detector output
    "gap": "policy_gap_analysis",         # NCCI floor vs AHCCCS overlay
    "bench": "policy_extraction_benchmark",
}

# Local mode paths
LOCAL_ROOT = os.environ.get("PKB_LOCAL_ROOT", os.path.join(os.path.dirname(__file__), "out"))

# ---------------------------------------------------------------- POC scope
# Deliberately narrow. One clinical area, two source types, three planes.
POC_NAME = "Outpatient Behavioral Health -- AHCCCS FFS"

# The BH code set this POC covers. Extraction and NCCI ingest are both
# filtered to this list so the demo stays interpretable.
POC_CODE_SET = [
    "H0018", "H0019", "H0031", "H0032", "H0034", "H0036", "H0038",
    "H2011", "H2012", "H2014", "H2015", "H2017", "H2019", "H2025", "H2033",
    "T1016", "T1017", "90832", "90834", "90837", "90846", "90847", "90853",
]

# ---------------------------------------------------------------- sources
# NCCI: download the PUBLIC Medicaid files yourself and drop them here.
#   https://www.cms.gov/medicare/coding-billing/ncci-medicaid/medicaid-ncci-edit-files
# Contractors use the public files; RISSNET is state-staff only. See README.
NCCI_MUE_PATH = os.environ.get("PKB_NCCI_MUE", "data/ncci_mue_practitioner.xlsx")
NCCI_PTP_PATH = os.environ.get("PKB_NCCI_PTP", "data/ncci_ptp_practitioner.xlsx")

# AHCCCS: drop the source PDFs here (the July 2023 Outpatient BH Billing deck etc.)
AHCCCS_PDF_DIR = os.environ.get("PKB_AHCCCS_PDFS", "data/ahcccs")

# ---------------------------------------------------------------- LLM
# STUB  : deterministic fake extractor. Full pipeline runs in seconds. Start here.
# DBFM  : Databricks Foundation Model serving endpoint (OpenAI-compatible).
# HFLOCAL: local transformers. 20B is CPU-feasible; 120B is not.
LLM_BACKEND = os.environ.get("PKB_LLM", "STUB")
DBFM_ENDPOINT = os.environ.get("PKB_DBFM_ENDPOINT", "databricks-gpt-oss-20b")
HF_MODEL = os.environ.get("PKB_HF_MODEL", "openai/gpt-oss-20b")
LLM_MAX_TOKENS = 2048
LLM_TEMPERATURE = 0.0  # extraction must be repeatable

# ---------------------------------------------------------------- claims
CLAIMS_TABLE = os.environ.get("PKB_CLAIMS", "synthetic_claims")
CLAIM_COLS = {
    "dos": "srvc_bgn_dt", "dos_end": "srvc_end_dt", "code": "proc_cd",
    "pos": "pos_cd", "units": "units", "member": "member_id",
    "provider": "provider_id", "provider_type": "provider_type",
    "discharge": "discharge_dt", "claim": "claim_id",
    "mods": ["mod_1", "mod_2", "mod_3", "mod_4"],
}
