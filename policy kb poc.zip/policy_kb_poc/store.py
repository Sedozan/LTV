"""
Storage adapter. One API, two backends.

LOCAL      -> parquet on disk (demo anywhere, no cluster)
DATABRICKS -> Delta in Unity Catalog (3-part names)

Writes are supersede-aware, never destructive: rules are appended with a
run_id and the current view is the latest non-superseded row per rule_id.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone

import pandas as pd

import config


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_run_id() -> str:
    return datetime.now(timezone.utc).strftime("run_%Y%m%dT%H%M%S")


def fq(table_key: str) -> str:
    """Fully-qualified table name. Always 3-part on Databricks."""
    name = config.TABLES[table_key]
    return f"{config.CATALOG}.{config.SCHEMA}.{name}"


# ---------------------------------------------------------------- spark

_spark = None


def spark():
    global _spark
    if _spark is None:
        from pyspark.sql import SparkSession
        _spark = SparkSession.builder.getOrCreate()
    return _spark


def ensure_schema():
    if config.MODE == "DATABRICKS":
        spark().sql(f"CREATE CATALOG IF NOT EXISTS {config.CATALOG}")
        spark().sql(f"CREATE SCHEMA IF NOT EXISTS {config.CATALOG}.{config.SCHEMA}")
    else:
        os.makedirs(config.LOCAL_ROOT, exist_ok=True)


# ---------------------------------------------------------------- io

# Columns that hold lists/dicts -- serialized to JSON so both backends agree.
_JSON_COLS = {"predicate", "codes", "required_claim_fields", "alternates",
              "allowed_pos", "required_modifiers"}


def _encode(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in df.columns:
        if c in _JSON_COLS or df[c].map(lambda v: isinstance(v, (list, dict))).any():
            df[c] = df[c].map(lambda v: json.dumps(v, default=str)
                              if isinstance(v, (list, dict)) else v)
    return df


def _decode(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in df.columns:
        if c in _JSON_COLS:
            df[c] = df[c].map(lambda v: json.loads(v) if isinstance(v, str) and v else v)
    return df


def write(table_key: str, rows: list[dict] | pd.DataFrame, run_id: str,
          mode: str = "append") -> int:
    """Append rows tagged with run_id. Returns row count written."""
    ensure_schema()
    df = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    if df.empty:
        return 0
    df["run_id"] = run_id
    df["ingested_at"] = _now()
    df = _encode(df)

    if config.MODE == "DATABRICKS":
        sdf = spark().createDataFrame(df)
        (sdf.write.format("delta").mode(mode)
            .option("mergeSchema", "true").saveAsTable(fq(table_key)))
    else:
        path, reader, writer = _local_target(table_key)
        if mode == "append" and os.path.exists(path):
            df = pd.concat([reader(path), df], ignore_index=True)
        writer(df, path)
    return len(df)


def _has_parquet() -> bool:
    try:
        import pyarrow  # noqa: F401
        return True
    except ImportError:
        try:
            import fastparquet  # noqa: F401
            return True
        except ImportError:
            return False


def _local_target(table_key: str):
    """Parquet when an engine exists, else CSV. The POC must never die on this."""
    base = os.path.join(config.LOCAL_ROOT, config.TABLES[table_key])
    if _has_parquet():
        return (base + ".parquet", pd.read_parquet,
                lambda d, p: d.to_parquet(p, index=False))
    return (base + ".csv", pd.read_csv,
            lambda d, p: d.to_csv(p, index=False))


def read(table_key: str) -> pd.DataFrame:
    if config.MODE == "DATABRICKS":
        try:
            return _decode(spark().table(fq(table_key)).toPandas())
        except Exception:
            return pd.DataFrame()
    path, reader, _ = _local_target(table_key)
    if not os.path.exists(path):
        return pd.DataFrame()
    return _decode(reader(path))


def current_rules() -> pd.DataFrame:
    """Latest non-superseded row per rule_id -- the live KB view."""
    df = read("rules")
    if df.empty:
        return df
    df = df.sort_values("ingested_at")
    df = df.drop_duplicates(subset=["rule_id"], keep="last")
    if "superseded" in df.columns:
        df = df[df["superseded"] != True]  # noqa: E712
    return df.reset_index(drop=True)


def reset():
    """POC convenience only. Never expose this in a real deployment."""
    if config.MODE == "DATABRICKS":
        for k in config.TABLES:
            spark().sql(f"DROP TABLE IF EXISTS {fq(k)}")
    else:
        if os.path.isdir(config.LOCAL_ROOT):
            for f in os.listdir(config.LOCAL_ROOT):
                if f.endswith((".parquet", ".csv")):
                    os.remove(os.path.join(config.LOCAL_ROOT, f))
