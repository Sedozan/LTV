"""
AHCCCS overlay extraction -- prose to rule objects.

This is the ONLY place an LLM touches rule logic. Its job is narrow: read a
section of AHCCCS text and emit structured predicates with citations. It does
not decide authority, does not resolve ambiguity, does not write SQL.

Windowing is section-level with no truncation: a rule split across a page
break is a rule you will get wrong.
"""
from __future__ import annotations

import hashlib
import os
import re

import config
from llm_client import complete_json, LLMError
from schema import Rule, PREDICATE_TYPES

SYSTEM = """You extract billing rules from Arizona Medicaid (AHCCCS) policy text.

Return ONLY a JSON array. No prose, no markdown fences. Each element:
{
  "statement": "one sentence, normalized, self-contained",
  "predicate": {"type": "<TYPE>", ...fields...},
  "codes": ["H2015"],
  "plane": "coverage_scope" | "coding_edit" | "enforcement",
  "binding_status": "state_policy" | "guidance" | "state_plan" | "contract",
  "population": "bh_outpatient" | "all" | "<other>",
  "machine_checkable": true|false,
  "not_checkable_reason": "no_claim_field" | "requires_medical_record" |
                          "requires_member_attribute" | "process_obligation" |
                          "ambiguous_source",
  "required_claim_fields": ["proc_cd","units"],
  "ambiguity_flag": true|false,
  "ambiguity_note": "...",
  "alternates": [{"threshold": 8, "locator": "slide 11"}],
  "effective_date": "YYYY-MM-DD",
  "source_locator": "slide 11 / section 3.2"
}

Allowed predicate types and their required fields:
  max_units_per_line   : code, threshold
  max_units_per_day    : code, threshold
  code_pair_prohibited : code_a, code_b
  pos_allowed          : code, allowed_pos (list)
  modifier_required    : code, required_modifiers (list)
  frequency_limit      : code, max_count, window_days
  provider_type_allowed: code, allowed_provider_types (list)
  not_checkable        : reason

HARD RULES:
1. Never invent a threshold, code, date or modifier. If the text does not
   state it, leave the field null and set machine_checkable=false.
2. If the same rule appears with DIFFERENT values in different places, emit
   ONE rule with ambiguity_flag=true, threshold=null, and every reading listed
   in alternates. Never pick one.
3. Set machine_checkable=true only if the rule can be tested against claim
   columns alone. Documentation, medical-necessity and prior-auth process
   obligations are false.
4. effective_date only if the text states it. Do not infer from a filename.
5. Extract only rules; skip definitions, glossaries and narrative background.
"""


# ---------------------------------------------------------------- sectioning

def read_pdf_sections(path: str, max_chars: int = 6000) -> list[tuple[str, str]]:
    """Return [(locator, text)]. Page-based for decks, heading-based for manuals."""
    import pdfplumber
    out: list[tuple[str, str]] = []
    with pdfplumber.open(path) as pdf:
        for i, page in enumerate(pdf.pages, 1):
            txt = (page.extract_text() or "").strip()
            if len(txt) < 40:
                continue
            if len(txt) <= max_chars:
                out.append((f"page/slide {i}", txt))
            else:
                for j in range(0, len(txt), max_chars):
                    out.append((f"page/slide {i} part {j // max_chars + 1}",
                                txt[j:j + max_chars]))
    return out


def doc_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


# ---------------------------------------------------------------- extraction

def _coerce(raw: dict, *, source_doc: str, locator: str, dhash: str,
            version: str) -> Rule | None:
    pred = raw.get("predicate") or {}
    if pred.get("type") not in PREDICATE_TYPES:
        return None
    codes = [str(c).strip().upper() for c in (raw.get("codes") or [])]
    r = Rule(
        origin="llm",
        plane=raw.get("plane", "coverage_scope"),
        binding_status=raw.get("binding_status", "guidance"),
        statement=str(raw.get("statement", "")).strip(),
        predicate=pred,
        codes=codes,
        population=raw.get("population", "all"),
        machine_checkable=bool(raw.get("machine_checkable", False)),
        not_checkable_reason=raw.get("not_checkable_reason"),
        required_claim_fields=raw.get("required_claim_fields") or [],
        ambiguity_flag=bool(raw.get("ambiguity_flag", False)),
        ambiguity_note=raw.get("ambiguity_note"),
        alternates=raw.get("alternates") or [],
        source_doc=source_doc,
        source_locator=raw.get("source_locator") or locator,
        doc_hash=dhash,
        doc_version=version,
        effective_date=raw.get("effective_date"),
    )
    return r.assign_id()


def extract_document(path: str, code_filter: list[str] | None = None
                     ) -> tuple[list[Rule], list[dict]]:
    """Returns (rules, errors). Errors are persisted, never dropped."""
    source_doc = os.path.basename(path)
    dhash = doc_hash(path)
    rules: list[Rule] = []
    errors: list[dict] = []

    for locator, text in read_pdf_sections(path):
        if code_filter and not any(c in text for c in code_filter):
            continue
        try:
            raw_list = complete_json(SYSTEM, f"[{locator}]\n\n{text}")
        except (LLMError, Exception) as e:  # noqa: BLE001 -- persist, keep going
            errors.append({"source_doc": source_doc, "locator": locator,
                           "error": str(e)[:500], "section_text": text})
            continue
        if isinstance(raw_list, dict):
            raw_list = [raw_list]
        for raw in raw_list:
            try:
                r = _coerce(raw, source_doc=source_doc, locator=locator,
                            dhash=dhash, version=source_doc)
                if r:
                    rules.append(r)
            except Exception as e:  # noqa: BLE001
                errors.append({"source_doc": source_doc, "locator": locator,
                               "error": f"coerce: {e}", "section_text": text[:2000]})
    return rules, errors


def extract_dir(dirpath: str, code_filter: list[str] | None = None
                ) -> tuple[list[Rule], list[dict]]:
    code_filter = code_filter if code_filter is not None else config.POC_CODE_SET
    rules, errors = [], []
    if not os.path.isdir(dirpath):
        return rules, errors
    for fn in sorted(os.listdir(dirpath)):
        if fn.lower().endswith(".pdf"):
            r, e = extract_document(os.path.join(dirpath, fn), code_filter)
            rules += r
            errors += e
    return rules, errors


# ---------------------------------------------------------------- demo text

def extract_from_text(text: str, source_doc: str, locator: str = "demo section"
                      ) -> list[Rule]:
    """Extract from a raw string. Used by the POC when no PDF is present."""
    raw_list = complete_json(SYSTEM, f"[{locator}]\n\n{text}")
    if isinstance(raw_list, dict):
        raw_list = [raw_list]
    out = []
    for raw in raw_list:
        r = _coerce(raw, source_doc=source_doc, locator=locator,
                    dhash=hashlib.sha256(text.encode()).hexdigest()[:16],
                    version="inline")
        if r:
            out.append(r)
    return out
